package com.example.myfirstdatabase;
import android.view.View;

public class Student {
    // fields
    private int studentID;
    private String studentName, lst;
    // constructors
    public Student() {}


    public void loadStudents(View view) {
        MyDBHandler dbHandler = new MyDBHandler((context)this, null, null, 1);
        lst.setText(dbHandler.loadHandler());
        studentID.setText("");
        studentName.setText("");
    }


    public void addStudent(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        int id = Integer.parseInt(studentid.getText().toString());
        String name = studentname.getText().toString();
        Student student = new Student(id, name);
        dbHandler.addHandler(student);
        studentid.setText("");
        studentname.setText("");
    }


    public Student(int id, String studentName) {
        studentID = id;
        this.studentName = studentName;
    }
    // properties
    public void setID(int id) {
        studentID = id;
    }
    public int getID() {
        return studentID;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    public String getStudentName() {
        return this.studentName;
    }
}